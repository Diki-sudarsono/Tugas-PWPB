<?php

class User_model {
    private $nama = 'Prof.Diki Sudarsonic,SE.';

    public function  getUser()
    {
        return $this->nama;
    }
}