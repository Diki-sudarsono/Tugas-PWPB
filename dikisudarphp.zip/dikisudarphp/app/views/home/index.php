<div class="container">
    <div class="jumbotron mt-4">
    <h1 class="display-4">SELAMAT DATANG DI WEB KAMI :) </h1>
    <p class="lead">Hallo, saya punya nama <?= $data['nama']; ?></p>
     <hr class="my-4">
     <p>Web ini sedang dalam pengembangan , jadi buat kalian yang mau download cheat PB premium pekalongan datang kapan-kapan lagi ya
     , karena web kita servernya sedang down , update terus cheat game kamu hanya di DIKI BLOG . #AnjooySmabar
     Follow Us On FB : Dicky Up Gan (Terima Mabar Ranked)</p>
     <a class="btn btn-danger btn-lg" href="#" role="button">Learn more</a>
     </div>
</div>