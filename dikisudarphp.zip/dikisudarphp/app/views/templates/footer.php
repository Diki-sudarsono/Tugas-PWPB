<script src="js/jquery-3.3.1.slim.min.js" ></script>
    <script src="js/popper.min.js" ></script>
    <script src="js/bootstrap.js" ></script>
    <script src="js/Script.js" ></script>
    <script src="jquery/jquery-3.4.1.js" ></script>

</body>
</html>