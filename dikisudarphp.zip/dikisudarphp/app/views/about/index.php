<div class="container text-center">
    <h1 class="mt-3">About Me</h1>
    <img src="<?= BASEURL; ?> ../img/1.jpg"width='25%' class="rounded-circle shadow" > 
    <p>Hallo, Saya punya nama <?= $data['nama']; ?>, Saya punya pekerjaan <?= $data['pekerjaan'] ?>
</div>